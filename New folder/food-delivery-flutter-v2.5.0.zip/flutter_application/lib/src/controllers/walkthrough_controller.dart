import 'package:mvc_pattern/mvc_pattern.dart';

class WalkthroughController extends ControllerMVC {}
